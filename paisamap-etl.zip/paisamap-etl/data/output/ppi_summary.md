# PaisaMap PPI — validation report

- PASS  PPI(110003) > PPI(110017) [141 vs 102]
- PASS  PPI(110017) > PPI(110040) [102 vs 47]
- PASS  drop property_rates: max PPI swing 2 pts
- PASS  drop bank_deposits: max PPI swing 1 pts
- PASS  drop vehicle_density: max PPI swing 1 pts
- PASS  drop nightlights: max PPI swing 2 pts
- PASS  drop itr_filers: max PPI swing 1 pts
- PASS  drop poi_density: max PPI swing 1 pts
